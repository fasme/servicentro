
@extends('layouts.master')
 

@section('breadcrumb')
<ul class="breadcrumb">
            <li>
              <i class="fa fa-home home-fa fa"></i>
              <a href="#">Home</a>

              <span class="divider">
                <i class="fa fa-angle-right arrow-fa fa"></i>
              </span>
            </li>

            <li>
              <a href={{ URL::to('cheques') }}>Cheques</a>

              <span class="divider">
                <i class="fa fa-angle-right arrow-fa fa"></i>
              </span>
            </li>
            <li>Ver Cheques</li>
          </ul><!--.breadcrumb-->

          @stop

@section('contenido')





        <h1>
  Cheques

</h1>
        {{ HTML::link('cheques/nuevo', 'Crear Cheque'); }}
 
<table id="example" class="table table-striped table-bordered table-hover">
  <thead>
          <tr >
            <th>Obra - Partida</th>
            <th>Proveedor</th>
            <th>Factura</th>
            <th>Monto</th>
            <th>N Cheque</th>
            <th>Fecha Pago</th>
            <th>Estado</th>
            <th>Revision</th>
            <th>Acciones</th>
            
          </tr>
        </thead>
        <tbody>
  @foreach($cheques as $cheque)

 

           <tr><td>
        


                    {{  $cheque->obra->nombre }}
                    <br>
            /

            {{ $cheque->partida->nombre }}
           
    
      
  </td>
  <td> {{ $cheque->proveedor }}
 
</td>
  <td>{{ $cheque->factura }}</td>
  <td>{{ $cheque->monto }}</td>
<td>{{ $cheque->numero }}</td>
  <td> {{ date_format(date_create($cheque->fechapago),'d/m/Y')  }} </td>

  <td>

  @if (date("Y-m-d") < $cheque->fechapago) 
 <span class="label label-success arrowed-in">
 Vigente 



{{CalcularDiasCheque($cheque->fechapago)}}

 </span>
  @else
  <span class="label label-inverse arrowed arrowed-righ">
 Vencido
 </span>
  @endif
</td>

   <td>
@if ( $cheque->revision === "1")
<span class="label label-success">
   Revisado
   </span>

@elseif ( $cheque->revision === "2")
<span class="label label-warning">
   Revisar
   </span>

@elseif ( $cheque->revision === "3")
<span class="label label-warning">
   Pendiente
   </span>


@endif


  </td>
  <td class="td-actions">
                       
                          <a class="blue" href={{'cheques/'.$cheque->id }}>
                            <i class='fa fa-zoom-in bigger-130'></i>
                          </a>


                          <a class="green" href= {{ 'cheques/editar/'.$cheque->id }}>
                            <i class="fa fa-pencil bigger-130"></i>
                          </a>

                          <a class="red" href="#">
                            <i class="fa fa-trash bigger-130"></i>
                          </a>
     
                      </td>
</tr>
          @endforeach
        </tbody>
  </table>


  <script type="text/javascript">


$('#example').DataTable( {
        dom: 'T<"clear">lfrtip',
        tableTools: {
            "sSwfPath": "TableTools/swf/copy_csv_xls_pdf.swf"
        }
    } );

$( "#chequeactive" ).addClass( "active" );

 </script>




        

        


@stop

