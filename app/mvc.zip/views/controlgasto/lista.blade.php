
@extends('layouts.master')
 


@section('breadcrumb')
<ul class="breadcrumb">
            <li>
              <i class="fa fa-home home-fa fa"></i>
              <a href="#">Home</a>

              <span class="divider">
                <i class="fa fa-angle-right arrow-fa fa"></i>
              </span>
            </li>

            <li>
              <a href={{ URL::to('proyectos') }}>Control Gasto</a>

              <span class="divider">
                <i class="fa fa-angle-right arrow-fa fa"></i>
              </span>
            </li>
            <li>Ver Control Gasto</li>
          </ul><!--.breadcrumb-->

          @stop

@section('contenido')




<div class="page-header position-relative">
        <h1>
  Control de gastos

</h1>
</div>
        {{ HTML::link('controlgasto/nuevo', 'Crear Control de  gasto'); }}
 

 <table id="example" class="table table-striped table-bordered table-hover">
  <thead>
          <tr >
            <th>Fecha</th>
            <th>Desc</th>
            <th>Prov</th>
            <th>Doc</th>
            <th>Neto</th>
             <th>Total</th>
             <th>Obra</th>
             <th>Concepto</th>

         
            <th>Acciones</th>
            
          </tr>
        </thead>

        <tfoot>
            <tr>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                 <th></th>
              
            </tr>
        </tfoot>


        <tbody>
  @foreach($controlgastos as $controlgasto)

 

           <tr>
  <td>  {{ date_format(date_create($controlgasto->fecha),'d/m/Y')  }}</td>
  <td>{{ $controlgasto->desc }}</td>
  <td>{{ $controlgasto->proveedor }}</td>
<td>{{ $controlgasto->documento }}</td>
  <td>{{ $controlgasto->neto }} </td>
  <td>{{ $controlgasto->neto*1.19 }} </td>
  <td>{{ $controlgasto->obra->nombre }} </td>

  <td>{{ $controlgasto->concepto }} / 
    @if($controlgasto->concepto == "GG")
    {{ $controlgasto->controlgastogg->id }} </td>
    @endif


  <td class="td-actions">
                       
                          <a class="blue" href={{'cheques/'.$controlgasto->id }}>
                            <i class='fa fa-zoom-in bigger-130'></i>
                          </a>


                          <a class="green" href= {{ 'cheques/editar/'.$controlgasto->id }}>
                            <i class="fa fa-pencil bigger-130"></i>
                          </a>

                          <a class="red" href="#">
                            <i class="fa fa-trash bigger-130"></i>
                          </a>
     
                      </td>
</tr>
          @endforeach
        </tbody>
  </table>


  <script type="text/javascript">
/*
 $('#example tfoot th').each( function () {
        var title = $('#example thead th').eq( $(this).index() ).text();
        $(this).html( '<input type="text" size="1" placeholder="Buscar '+title+'" />' );
        alert(this);
    } );
*/


$("#example tfoot th").eq(1).html('<input type="text" size="1" placeholder="Buscar" style="width:50px" />');
$("#example tfoot th").eq(6).html('<input type="text" size="1" placeholder="Buscar" style="width:50px" />');
$("#example tfoot th").eq(7).html('<input type="text" size="1" placeholder="Buscar" style="width:50px" />');



var table  = $('#example').DataTable( {
        dom: 'T<"clear">lfrtip',
        tableTools: {
            "sSwfPath": "js/TableTools/swf/copy_csv_xls_pdf.swf",
            "aButtons": [
        {
            "sExtends": "copy",
            "sButtonText": "Copy",
            "oSelectorOpts": {
                page: 'current'
            }
        },

        {
            "sExtends": "xls",
            "sButtonText": "Xls",
            "oSelectorOpts": {
                page: 'current'
            }
        }

    ]
        },
         "footerCallback": function ( row, data, start, end, display ) {
      
          var api = this.api(), data;
     
            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
 
            // Total over all pages
            total = api
                .column( 4 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                } );
 
            // Total over this page
            pageTotal = api
                .column( 4, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
 
            // Update footer
            $( api.column( 4 ).footer() ).html(
                '$'+pageTotal +' ( $'+ total +' total)'
            );



            total = api
                .column( 5 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                } );
 
            // Total over this page
            pageTotal = api
                .column( 5, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
 
            // Update footer
            $( api.column( 5 ).footer() ).html(
                '$'+pageTotal +' ($'+ total +' total)'
            );


         }
    } );


table.columns().eq( 0 ).each( function ( colIdx ) {
        $( 'input', table.column( colIdx ).footer() ).on( 'keyup change', function () {
             table
                .column( colIdx )
                .search( this.value )
                .draw();
        } );

      });


$( "#controlgastoactive" ).addClass( "active" );

 </script>





        


@stop

