
@extends('layouts.master')
 


@section('breadcrumb')
<ul class="breadcrumb">
            <li>
              <i class="icon-home home-icon"></i>
              <a href="#">Home</a>

              <span class="divider">
                <i class="icon-angle-right arrow-icon"></i>
              </span>
            </li>

            <li>
              <a href={{ URL::to('orden') }}>orden</a>

              <span class="divider">
                <i class="icon-angle-right arrow-icon"></i>
              </span>
            </li>
            <li>Ver orden</li>
          </ul><!--.breadcrumb-->

          @stop

@section('contenido')





        <h1>
  ordenes

</h1>
        {{ HTML::link('orden/nuevo', 'Crear Orden'); }}
 
<table id="example" class="table table-striped table-bordered table-hover">
  <thead>
          <tr>
            <th>Numero</th>
            <th>Fecha</th>
            <th>Proveedor</th>
            <th>Neto</th>
            <th>Total</th>
            <th>Acciones</th>
            
          </tr>
        </thead>
        <tbody>



  @foreach($ordenes as $orden)
           <tr>

            <td> {{  $orden->ordencompra_id }}</td>
            <td> {{  date_format(date_create($orden->fecha),'d/m/Y') }}</td>
             <td> {{  $orden->proveedor->nombre }}</td>


             <td> {{  $orden->valorneto }}</td>
             <td> {{  round($orden->valorneto * 1.19)}}</td>

              

 
  <td class="td-actions">
                       
                          <a class="blue" href={{'ordencompra/'.$orden->ordencompra_id }}>
                            <i class='fa fa-zoom-in bigger-130'></i>
                          </a>


                          <a class="green" href= {{ 'ordencompra/editar/'.$orden->ordencompra_id }}>
                            <i class="fa fa-pencil bigger-130"></i>
                          </a>

                          <a class="red" href="#">
                            <i class="fa fa-trash bigger-130"></i>
                          </a>

                          <a class="red" href={{ 'ordencompra/pdf/'.$orden->ordencompra_id }}>
                            <i class="fa fa-file-pdf-o  bigger-130"></i></a>

                          <a class="green" href={{ 'ordencompra/xls/'.$orden->ordencompra_id }}>
                            <i class="fa fa-file-excel-o bigger-130"></i>

                          </a>
     
                      </td>
</tr>
          @endforeach

    
        </tbody>
  </table>




  <script type="text/javascript">
 $(document).ready(function() {


$('#example').DataTable( {
        dom: 'T<"clear">lfrtip',
        tableTools: {
            "sSwfPath": "TableTools/swf/copy_csv_xls_pdf.swf"
        }
    } );


$( "#ordencompraactive" ).addClass( "active" );
});

 </script>



        

        


@stop

