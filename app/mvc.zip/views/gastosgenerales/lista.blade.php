
@extends('layouts.master')
 

@section('breadcrumb')
<ul class="breadcrumb">
            <li>
              <i class="fa fa-home home-fa fa"></i>
              <a href="#">Home</a>

              <span class="divider">
                <i class="fa fa-angle-right arrow-fa fa"></i>
              </span>
            </li>

            <li>
              <a href={{ URL::to('gastogeneral') }}>Gastos</a>

              <span class="divider">
                <i class="fa fa-angle-right arrow-fa fa"></i>
              </span>
            </li>
            <li>Ver Gastos Generales</li>
          </ul><!--.breadcrumb-->

          @stop

@section('contenido')





        <h1>
  Gastos generales

</h1>
        {{ HTML::link('gastogeneral/nuevo', 'Crear gasto general'); }}
 
<table id="example" class="table table-striped table-bordered table-hover">
  <thead>
          <tr >
            <th>Proyecto</th>
            <th>Categoria</th>
            <th>Nombre</th>
            <th>Unidad</th>
            <th>Cantidad</th>
            <th>Precio</th>
         
            <th>Acciones</th>
            
          </tr>
        </thead>
        <tbody>
  @foreach($gg as $gastos)
  <tr>
    <td>{{ $gastos->proyecto->nombre }}</td>
    <td>{{ $gastos->ggcategoria->nombre }}</td>
  <td> {{ $gastos->nombre }}</td>
  <td>{{ $gastos->unidad }}</td>
  <td>{{ $gastos->cantidad }}</td>
  <td>{{ $gastos->precio }}</td>

  <td class="td-actions">
                       
                          <a class="blue" href={{'cheques/'.$gastos->id }}>
                            <i class='fa fa-zoom-in bigger-130'></i>
                          </a>


                          <a class="green" href= {{ 'cheques/editar/'.$gastos->id }}>
                            <i class="fa fa-pencil bigger-130"></i>
                          </a>

                          <a class="red" href="#">
                            <i class="fa fa-trash bigger-130"></i>
                          </a>
     
                      </td>
</tr>
          @endforeach
        </tbody>
  </table>


  <script type="text/javascript">
 $(document).ready(function() {

$('#example').DataTable( {
        dom: 'T<"clear">lfrtip',
        tableTools: {
            "sSwfPath": "TableTools/swf/copy_csv_xls_pdf.swf"
        }
    } );


$( "#gastogeneralactive" ).addClass( "active" );
});
 </script>




        

        


@stop

