
@extends('layouts.master')
 


@section('breadcrumb')
<ul class="breadcrumb">
            <li>
              <i class="fa fa-home home-fa fa"></i>
              <a href="#">Home</a>

              <span class="divider">
                <i class="fa fa-angle-right arrow-fa fa"></i>
              </span>
            </li>

            <li>
              <a href={{ URL::to('proyectos') }}>Proyectos</a>

              <span class="divider">
                <i class="fa fa-angle-right arrow-fa fa"></i>
              </span>
            </li>
            <li>Ver Proyectos</li>
          </ul><!--.breadcrumb-->

          @stop

@section('contenido')




<div class="page-header position-relative">
        <h1>
  Proyectos

</h1>
</div>
        {{ HTML::link('usuarios/nuevo', 'Crear Usuario'); }}

        @if(isset($mensaje))
        <div class="alert alert-block alert-success">{{$mensaje}}</div>
        @endif
 
<table id="example" class="table table-striped table-bordered table-hover">
  <thead>
          <tr>
            <th>Nombre</th>
            <th>Plzao</th>
            <th>Fecha Inicio</th>
            <th>Fecha Termino</th>
            <th>Acciones</th>
            
          </tr>
        </thead>
        <tbody>
  @foreach($proyectos as $proyecto)
           <tr><td>
    {{  $proyecto->nombre }}
      
  </td>
  <td> {{ $proyecto->plazo }}</td>
  <td>
    @if ($proyecto->fechainicio > 0)
    {{ date_format(date_create($proyecto->fechainicio),'d/m/Y')  }}
    @endif
  </td>
  <td>
  @if ($proyecto->fechatermino > 0)
    {{ date_format(date_create($proyecto->fechatermino),'d/m/Y')  }}
    @endif
  </td>
  <td class="td-actions">
                       
                          <a class="blue" href={{'proyectos/session/'.$proyecto->id }}>
                            <i class='fa fa-briefcase bigger-130'></i>
                          </a>


                          <a class="green" href= {{ 'proyectos/editar/'.$proyecto->id }}>
                            <i class="fa fa-pencil bigger-130"></i>
                          </a>

                          <a class="red" id="myModal" data-target="#myModal">
                            <i class="fa fa-trash bigger-130"></i>
                          </a>
     
                      </td>
</tr>
          @endforeach
        </tbody>
  </table>




  <script type="text/javascript">
 $(document).ready(function() {


$('#example').DataTable( {
        dom: 'T<"clear">lfrtip',
        tableTools: {
            "sSwfPath": "TableTools/swf/copy_csv_xls_pdf.swf"
        }
    } );


$( "#proyectoactive" ).addClass( "active" );

$('#myModal').on('shown.bs.modal', function () {
   
  })


});
 </script>



        

        


@stop

