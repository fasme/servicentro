<?php
class Cheque extends Eloquent { //Todos los modelos deben extender la clase Eloquent
    protected $table = 'cheque';
    protected $fillable = array('obra_id', 'partida_id', 'proveedor','factura','pendiente','monto','numero','fechapago','observaciones','revision');
   


   public function obra()
    {
    	return $this->belongsTo('Obra');
    }


    public function partida()
    {
    	return $this->belongsTo('Partida');
    }

    public function oli()
    {
        return "hola";
    }



    public $errors;
    
    public function isValid($data)
    {
        $rules = array(
            'obra_id' => 'exists:obra,id',
            'partida_id' => 'exists:partida,id',
            'factura'     => 'required|integer',
            'monto' => 'required|integer',
            'numero'  => 'required|integer'
        );
        
        $validator = Validator::make($data, $rules);
        
        if ($validator->passes())
        {
            return true;
        }
        
        $this->errors = $validator->errors();
        
        return false;
    }


}
?>