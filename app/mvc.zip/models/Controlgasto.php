<?php
class Controlgasto extends Eloquent { //Todos los modelos deben extender la clase Eloquent
    protected $table = 'controlgasto';
    protected $fillable = array('fecha','desc','proveedor','documento','neto','ncheque','obra_id','concepto', 'proyecto_id');



  public function obra()
    {
        return $this->belongsTo('Obra');
    }


    public function ggcategoria()
    {
    	return $this->belongsTo('Ggcategoria');
    }

    public function controlgastogg()
    {
        return $this->hasOne('Controlgastogg');
    }

    public function controlgastocd()
    {
        return $this->hasMany('Controlgastocd');
    }






}
?>