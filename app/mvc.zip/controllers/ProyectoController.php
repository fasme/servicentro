<?php
class ProyectoController extends BaseController {

public function mostrarProyecto(){

	$proyectos = Proyecto::all();

	return View::make("proyectos.lista")->with("proyectos",$proyectos);

}

public function nuevoProyecto(){

	
	return View::make("proyectos.crear");
	//return "ho";
}


public function crearProyecto(){

	 $proyectos = Proyecto::create(Input::all());

	 $fechainicio = Input::get("fechainicio");
	list($dia,$mes,$ano) = explode("/",$fechainicio);
	 $fechainicio = "$ano-$mes-$dia";

	  $fechatermino = Input::get("fechatermino");
	list($dia,$mes,$ano) = explode("/",$fechatermino);
	 $fechatermino = "$ano-$mes-$dia";


	 $proyectos->fechainicio = $fechainicio;
	$proyectos->fechatermino = $fechatermino;

	$proyectos->save();


	return Redirect::to("proyectos");
}


public function sessionProyecto($id){
	//Session::put('proyecto', $id);
	$proyecto = Proyecto::find($id);
	Session::put('proyecto', $proyecto);
return Redirect::to("proyectos");
	
}

public function obras(){

	$proyectos = Proyecto::find(1)->obras;

	return View::make("proyectos.lista", array("proyectos"=>$proyectos));

}


public function editarProyecto($id){

	$proyecto = Proyecto::find($id);

	return View::make("proyectos.editar")->with("proyecto",$proyecto);
}

public function editarPost($id){


 $proyecto = Proyecto::find($id);
        $proyecto->nombre = Input::get("nombre");

         $fechainicio = Input::get("fechainicio");
	list($dia,$mes,$ano) = explode("/",$fechainicio);
	 $fechainicio = "$ano-$mes-$dia";

	  $fechatermino = Input::get("fechatermino");
	list($dia,$mes,$ano) = explode("/",$fechatermino);
	 $fechatermino = "$ano-$mes-$dia";


	 $proyecto->fechainicio = $fechainicio;
	$proyecto->fechatermino = $fechatermino;


        $proyecto->save();

}



}