<?php
class GastogeneralController extends BaseController {

public function mostrarGastos(){

	$gg = Gastogeneral::Where("proyecto_id","=",Session::get("proyecto")->id)->get();

	return View::make("gastosgenerales.lista", array("gg"=>$gg));

}

public function nuevoGasto(){
//where('proyecto_id',"=",Session::get("proyecto")->id)->get()->lists("nombre","id");
	/*
	$proyectos = Proyecto::find()->lists("nombre","id");
	array_unshift($proyectos, ' --- Seleccione un Proyecto --- ');
	$selected = array();
*/


	$ggcategorias = Ggcategoria::all()->lists("nombre","id");
	array_unshift($ggcategorias, ' --- Seleccione un Proyecto --- ');
	$selected2 = array();


	return View::make("gastosgenerales.crear",  compact('ggcategorias','selected2'));
	//return "ho";
}

public function crearGasto(){


	 $input = Input::get('gg');
	//return $input;
	//DB::table('gg')->insert($input);
   //Gastogeneral::create($input);
	

	for($i=0;$i<count($input);$i++)
{
	
	if($input[$i]["nombre"] != "")
	{
	//echo $input[$i]["nombre"];

		//array_push($input[$i], "ordencompra_id",$lastid);
		//dd($input[$i]);
	Gastogeneral::create(array("proyecto_id"=>Input::get("proyecto_id"),"ggcategoria_id"=>$input[$i]["ggcategoria_id"],"nombre"=>$input[$i]["nombre"],"unidad"=>$input[$i]["unidad"],"cantidad"=>$input[$i]["cantidad"],"precio"=>$input[$i]["precio"]));

	}
}


return Redirect::to('gastogeneral');
}




}