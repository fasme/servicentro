<?php
class ObraController extends BaseController {

public function mostrarObra(){

	//$obras = Obra::find(1);
	//echo Session::get("proyecto")->id;
	$obras = Obra::where('proyecto_id','=',Session::get("proyecto")->id)->get();

	return View::make("obras.lista", array("obras"=>$obras));

}

public function nuevoObra(){

	$proyectos = Proyecto::all()->lists("nombre","id");
	$selected = array();
	return View::make("obras.crear", compact('proyectos', 'selected'));
	//return "ho";
}

public function crearObra(){

	 $obras = Obra::create(Input::all());


	$obras->save();


	return Redirect::to("obras");

}




}