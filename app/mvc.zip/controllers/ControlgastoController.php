<?php
class ControlgastoController extends BaseController {


public function mostrarControlgasto(){

$controlgastos = Controlgasto::where("proyecto_id",'=',Session::get("proyecto")->id)->get();
        
        // Con el método all() le estamos pidiendo al modelo de Usuario
        // que busque todos los registros contenidos en esa tabla y los devuelva en un Array
        
        return View::make('controlgasto.lista', array('controlgastos' => $controlgastos));

}


public function nuevoControlgasto()
{

	$proyectos = Proyecto::all()->lists("nombre","id");
	$selected = array();

    $obras = Obra::Where("proyecto_id","=",Session::get("proyecto")->id)->lists("nombre","id");
  array_unshift($obras, ' --- Seleccione una obra --- ');
    $selected2 = array();

    $partidas = Partida::Where("proyecto_id","=",Session::get("proyecto")->id)->lists("nombre","id");
    array_unshift($partidas, ' --- Seleccione una partida --- ');

    $ggs = Ggcategoria::all()->lists("nombre","id");
array_unshift($ggs, ' --- Seleccione una categoria --- ');
    $selected3 = array();

 //return View::make('controlgasto.crear', compact('proyectos','selected'), compact('obras','selected2'), compact('ggs','selected3'));
    return View::make('controlgasto.crear')->with('proyectos',$proyectos)->with('obras',$obras)->with('ggs',$ggs)->with("partidas",$partidas);
}


public function crearControlgasto()
{

    $data = Input::all();

    $data['fecha'] = "2016-01-01";

    $controlgastos = Controlgasto::create($data);
    $lastid =  $controlgastos->id;

    if($data["concepto"] == "GG")
    {
        Controlgastogg::create(array("controlgasto_id"=>$lastid,"ggcategoria_id"=>$data["ggcategoria_id"]));
        echo "gg";
    }
    else if($data["concepto"] == "CD")
    {
        Controlgastocd::create(array("controlgasto_id"=>$lastid,"partida_id"=>$data["partida_id"]));
        echo "cd";
    }
   // return Redirect::to('controlgasto');



}


public function getDatatable()
    {
        return Datatable::Collection(Controlgasto::all(array('id','desc')))
        ->showColumns('id', 'desc')
        ->searchColumns('desc')
        ->orderColumns('id','desc')
        
        ->make();
    }



}

?>