<?php
class OrdencompraController extends BaseController {


public function mostrarOrden(){

//$ordenes = Ordencompra::all();
//$ordenes = DB::select('select * from ordencompra');



/*
$ordenes = DB::table('ordencompra')
->leftJoin('ordencompradetalle','ordencompra.id','=','ordencompradetalle.ordencompra_id')
->select(DB::raw('*,sum(valoru*cantidad) as valoru'))->get();

*/

/*$ordenes = Ordencompra::leftJoin('ordencompradetalle', function($join) {
      $join->on('ordencompra.id', '=', 'ordencompradetalle.ordencompra_id');
    })
//->join('ordencompradetalle','ordencompra.id','=','ordencompradetalle.ordencompra_id')
->select(DB::raw('*,sum(valoru*cantidad) as valoru'))
->where("ordencompra.id", "=", "ordencompradetalle.ordencompra_id")
->get();

*/

$ordenes = Ordencompra::Join("ordencompradetalle","ordencompradetalle.ordencompra_id","=",'ordencompra.id')
->groupBy('ordencompradetalle.ordencompra_id')
->select(DB::raw('*,sum(valoru*cantidad) as valorneto'))
->get();


//return count($ordenes);
//return $ordenes;
return View::make("ordencompra.lista")->with("ordenes", $ordenes);
}


public function nuevoOrden()
{
	$proveedores = Proveedor::all()->lists("nombre","id");
	array_unshift($proveedores, ' --- Seleccione un Proveedor --- ');
	$selected = array();


	return View::make("ordencompra.crear", compact('proveedores', 'selected'));
	//return "ho";

}


public function crearOrden()
{


      $fecha = Input::get('fecha');
	list($dia,$mes,$ano) = explode("/",$fecha);
	 $fecha = "$ano-$mes-$dia";

$ordencompra = Ordencompra::create(array('proveedor_id'=>Input::get('proveedor_id'),'fecha'=>$fecha));
$lastid =  $ordencompra->id;

  $input = Input::get('oc');


for($i=0;$i<count($input);$i++)
{
	
	if($input[$i]["nombre"] != "")
	{
	//echo $input[$i]["nombre"];

		//array_push($input[$i], "ordencompra_id",$lastid);
		//dd($input[$i]);
	Ordencompradetalle::create(array("nombre"=>$input[$i]["nombre"],"cantidad"=>$input[$i]["cantidad"],"medida"=>$input[$i]["medida"],"valoru"=>$input[$i]["valoru"],"ordencompra_id"=>$lastid));

	}
}


return Redirect::to('ordencompra');
 




}


public function generarOrdenPDF($id){




		 $ordenes = Ordencompra::find($id);

	   $html =  View::make("ordencompra.pdf")->with("ordenes",$ordenes);

      return PDF::load($html, 'A4', 'portrait')->show();


}


public function generarOrdenXLS($id){
/*
$ordenes = Ordencompra::find($id);
	return $html =  View::make("ordencompra.xls")->with("ordenes",$ordenes);
*/

Excel::create('New file', function($excel) use($id) {

    $excel->sheet('New sheet', function($sheet) use($id) {

    	$ordenes = Ordencompra::find($id);
        $sheet->loadView('ordencompra.xls')->with("ordenes",$ordenes);
$sheet->setWidth('B', 50);
$sheet->setWidth('C', 50);
        $sheet->cell('C1', function($cell) {
//
});

    });

})->export('xlsx');;



}







}

?>